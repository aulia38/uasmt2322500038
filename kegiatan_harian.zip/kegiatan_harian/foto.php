<?php
header("Access-Control-Allow-Origin: *");

$file = $_GET["f"] ?? "";
$file = urldecode($file);

if ($file == "") {
    http_response_code(400);
    exit;
}

$path = __DIR__ . "/foto/" . basename($file);

if (!file_exists($path)) {
    http_response_code(404);
    exit;
}

$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
$mime = [
    "jpg" => "image/jpeg",
    "jpeg" => "image/jpeg",
    "png" => "image/png",
    "gif" => "image/gif"
];

header("Content-Type: " . ($mime[$ext] ?? "application/octet-stream"));
readfile($path);
exit;
