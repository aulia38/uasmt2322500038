<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET");
header("Access-Control-Allow-Headers: Content-Type");

error_reporting(0);
include "koneksi_kegiatan.php";

$aksi = $_POST["aksi"] ?? "";

function uploadFoto($fieldName = "foto")
{
    if (!isset($_FILES[$fieldName]) || $_FILES[$fieldName]["error"] != 0) {
        return null;
    }

    $ext = pathinfo($_FILES[$fieldName]["name"], PATHINFO_EXTENSION);
    $namaBaru = time() . "_" . rand(1000, 9999) . "." . $ext;

    $folder = __DIR__ . "/foto/";
    if (!is_dir($folder)) {
        mkdir($folder, 0777, true);
    }

    move_uploaded_file($_FILES[$fieldName]["tmp_name"], $folder . $namaBaru);
    return $namaBaru;
}

switch ($aksi) {
    case "tampil":
        $sql = "SELECT * FROM kegiatan ORDER BY tanggal DESC";
        $result = mysqli_query($koneksi, $sql);

        $data = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }

        echo json_encode($data);
        break;

    case "simpan":
        $tanggal        = $_POST["tanggal"];
        $judul_kegiatan = $_POST["judul_kegiatan"];
        $deskripsi      = $_POST["deskripsi"];
        $kategori       = $_POST["kategori"];
        $tanggal_input  = $_POST["tanggal_input"];

        $foto = uploadFoto("foto");

        $sql = "INSERT INTO kegiatan (
    tanggal,
    judul_kegiatan,
    deskripsi,
    kategori,
    tanggal_input,
    foto
) VALUES (
    '$tanggal',
    '$judul_kegiatan',
    '$deskripsi',
    '$kategori',
    '$tanggal_input',
    '$foto'
)";


        if (mysqli_query($koneksi, $sql)) {
            echo json_encode(["status" => "berhasil"]);
        } else {
            echo json_encode(["status" => "gagal"]);
        }
        break;


    case "ubah":
        $id_kegiatan    = $_POST["id_kegiatan"];
        $tanggal        = $_POST["tanggal"];
        $judul_kegiatan = $_POST["judul_kegiatan"];
        $deskripsi      = $_POST["deskripsi"];
        $kategori       = $_POST["kategori"];


        $fotoBaru = uploadFoto("foto");

        if ($fotoBaru) {
            $sql = "UPDATE kegiatan SET
        tanggal='$tanggal',
        judul_kegiatan='$judul_kegiatan',
        deskripsi='$deskripsi',
        kategori='$kategori',
        foto='$fotoBaru'
    WHERE id_kegiatan='$id_kegiatan'";
        } else {
            $sql = "UPDATE kegiatan SET
        tanggal='$tanggal',
        judul_kegiatan='$judul_kegiatan',
        deskripsi='$deskripsi',
        kategori='$kategori'
    WHERE id_kegiatan='$id_kegiatan'";
        }


        if (mysqli_query($koneksi, $sql)) {
            echo json_encode(["status" => "berhasil"]);
        } else {
            echo json_encode(["status" => "gagal"]);
        }
        break;

    case "hapus":
        $id_kegiatan = $_POST["id_kegiatan"];

        $q = mysqli_query($koneksi, "SELECT foto FROM kegiatan WHERE id_kegiatan='$id_kegiatan'");
        $d = mysqli_fetch_assoc($q);

        if ($d["foto"]) {
            @unlink(__DIR__ . "/foto/" . $d["foto"]);
        }

        $sql = "DELETE FROM kegiatan WHERE id_kegiatan='$id_kegiatan'";
        if (mysqli_query($koneksi, $sql)) {
            echo json_encode(["status" => "berhasil"]);
        } else {
            echo json_encode(["status" => "gagal"]);
        }
        break;

    default:
        echo json_encode(["error" => "aksi tidak valid"]);
}
